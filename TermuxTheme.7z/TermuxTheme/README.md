
## What's this used for?
TermuxTheme, this is one of the best Termux themer that used to switch Termux from black and white into colorfully mode of hackers, one of the best thing with this tool is that as we all know most of the Termux color tools has some ERROS which while typing commands they just keep repeating by going back however this is very useless so, you can use this tool and it will never repeating your typing or get back confirmed InshaAllah.

## AVAILABLE ON :
* Termux Only

### THE TOOL REQUIREMENTS:
* Termux From Fdroid
* mpv the will install auto
* python3, pip, lolcat, figlet


## INSTALLATION ON [Termux] :

* `pkg update -y`
* `pkg upgrade -y`
* `pkg install git -y`
```
git clone https://github.com/Hzsa-anony/TermuxThemeall
```
* `cd TermuxTheme`
* `chmod 777 *`
* `./setup`
* `ls`
* `./TermuxTheme.sh`


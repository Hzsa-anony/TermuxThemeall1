#!/bin/bash
# coded by H.Z.sA (H.Z.sA)
# Created since on 17/10/2022 made in Nigeria by H.Z.sA (sA)
# If You Take Money For This Little Tool Bash Script Please Look At Your Self Again And Shame To You.
# visit our website https://h.z.sa.org
clear
sleep 0.5
echo ""
echo "  [VISIT https://h.z.sa.org TO LEARN MORE]"|lolcat
echo "    _____   _____ _   _ _____ __  __ _____"|lolcat
echo "   |_   _| |_   _| | | | ____|  \/  | ____|"|lolcat
echo "     | |_____| | | |_| |  _| | |\/| |  _|"  |lolcat
echo "     | |_____| | |  _  | |___| |  | | |___" |lolcat
echo "     |_|     |_| |_| |_|_____|_|  |_|_____| V1.5"|lolcat
echo "  [CREATED BY: H.Z.sA]"|lolcat
sleep 0.5
echo ""
echo "You Are About To Switch Termux To Colorfully Mode."|lolcat
read -p 'Press Enter To Continue Or Press CTRL + Z To Cancel'
echo ""
echo ""
sleep 0.5
echo "Ok Your Termux Theme Will Change Now"|lolcat
sleep 2.0
echo " Please Wait For 10 Seconds To Make The Changes..."|lolcat
sleep 2.0
cd
cd /$HOME
rm //data/data/com.termux/files/usr/etc/bash.bashrc
cd
mv /data/data/com.termux/files/home/TermuxTheme/code/bash.bashrc //data/data/com.termux/files/usr/etc/bash.bashrc
sleep 8.0
echo "Completed, Your Termux Now Looking Awesome"|lolcat
sleep 1.0
echo ""
echo ""
echo "Please exit from the termux and open it again to see the changes."|lolcat
echo "CREATOR BY H.Z.sA"|lolcat
echo "FOLLOW MY GITHUB : hzsa-anony"|lolcat
echo "SV No WA saya buat nambah kontak aja \[e[1;33m]https://whatsapp.com/6289677303455"|lolcat
echo "nomor wa Bot \[e[1;33m]https://whatsapp.com/6282195833065 "|lolcat
echo "VISIT https://h.z.sa.org TO LEARN MORE."
echo "gada lu bau"
